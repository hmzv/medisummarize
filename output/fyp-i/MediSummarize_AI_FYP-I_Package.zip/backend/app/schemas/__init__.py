"""Pydantic schemas."""
